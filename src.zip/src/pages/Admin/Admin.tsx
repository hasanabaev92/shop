function Admin() {

    return (
        <>
         <div>Админ</div>
        </>
    )

}

export default Admin