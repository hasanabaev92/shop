function Cart() {


  return (
    <>
         <div>Корзина</div>
    </>
  )
}

export default Cart